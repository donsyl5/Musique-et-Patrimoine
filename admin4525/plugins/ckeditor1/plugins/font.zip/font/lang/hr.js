/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'hr', {
	fontSize: {
		label: 'Veličina',
		voiceLabel: 'Veličina slova',
		panelTitle: 'Veličina'
	},
	label: 'Font',
	panelTitle: 'Font',
	voiceLabel: 'Font'
} );
